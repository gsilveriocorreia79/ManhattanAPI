package io.github.zealbuquerque.exception;

public class RegraNegocioException extends RuntimeException {

    public RegraNegocioException(String message){
        super(message);
    }
}
