package io.github.zealbuquerque.domain.enums;

public enum StatusPedido {

    REALIZADO,
    CANCELADO;
}
